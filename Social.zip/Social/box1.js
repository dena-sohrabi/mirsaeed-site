import { StyleSheet, Image, View, Text, Pressable } from "react-native";

export function Box({ source, title1, title2 }) {
  return (
    <>
      <View style={styles.container}>
        <Image
          source={{ uri: source, width: 80, height: 70 }}
          style={styles.img}
        />
        <Text style={styles.h1}>{title1}</Text>
        <Text style={styles.p} numberOfLines={3}>
          {title2}
        </Text>
        <Pressable style={styles.docme}>مشاهده</Pressable>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    maxWidth: 300,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  h1: {
    fontStyle: "normal",
    fontWeight: "normal",
    fontSize: 22,
    lineHeight: 36,
    textAlign: "right",
    color: "#FFFFFF",
    paddingTop: 22,
  },
  p: {
    fontStyle: "normal",
    fontWeight: 300,
    fontSize: 18,
    lineHeight: 30,
    textAlign: "center",
    color: "#D9D9D9",
    width: 200,
    paddingTop: 10,
  },
  docme: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 80,
    height: 30,
    backgroundColor: "#fff",
    borderRadius: 30,
    marginTop: 20,
  },
});
