import { StyleSheet, View, Text } from "react-native";

export function MenoItem({ title }) {
  return (
    <View style={styles.linbox}>
      <Text style={styles.line}>____</Text>

      <Text style={styles.p}>{title}</Text>

      <Text style={styles.line}>__</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  linbox: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },

  line: {
    color: "red",
    fontWeight: "bold",
  },

  p: {
    fontStyle: "bold",
    fontWeight: "600",
    fontSize: 20,
    lineHeight: 31,
    textAlign: "right",
    color: "#555555",
  },
});
