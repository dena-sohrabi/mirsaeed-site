import { StyleSheet, Image } from "react-native";
import { Media } from "../pages/media";

export function Circle(props) {
  return (
    <>
      {/* <Media at="sm"></Media> */}
      <Media greaterThan="sm">
        <Image
          source={{
            uri: "/Ellipse.png",
            width: 100,
            height: 120,
          }}
          style={styles.logo}
        />
      </Media>
    </>
  );
}

const styles = StyleSheet.create({
  logo: {
    position: "absolute",
    top: -200,
  },
});
