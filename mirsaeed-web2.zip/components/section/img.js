import { StyleSheet, Image, View } from "react-native";
import { Media } from "../../pages/media";

export function Logo(props) {
  return (
    <>
      <Media at="sm">
        <Image
          source={{
            uri: "/Vector100.png",
            width: 350,
            height: 290,
          }}
          style={styles.logo}
        />
      </Media>
      <Media greaterThan="sm">
        <Image
          source={{
            uri: "/Vector100.png",
            width: 480,
            height: 400,
          }}
          style={{ marginTop: -70, marginRight: 80 }}
        />
      </Media>
    </>
  );
}

const styles = StyleSheet.create({
  logo: {
    marginTop: -50,
  },
});
