import { StyleSheet, View, ScrollView } from "react-native";
import { Circle } from "../components/circle";
import Header from "../components/header/header";
import Section from "../components/section/section";
import { MediaContextProvider, Media } from "./media";
export default function App(props) {
  return (
    <ScrollView style={{ height: "100vh" }}>
      <MediaContextProvider>
        <Media at="sm">
          <View
            style={{
              backgroundColor: "#EEE7E7",
              width: "100%",
            }}
          >
            <View style={styles.container}>
              <Header />
              <Section />
            </View>
          </View>
        </Media>
        <Media greaterThan="sm">
          <View
            style={{
              backgroundColor: "#EEE7E7",
              width: "100%",
            }}
          >
            <View style={styles.container}>
              <Header />
            </View>
            <View style={styles.container}>
              <View style={styles.box}>
                <Circle />
              </View>
            </View>
            <View style={styles.container}>
              <Section />
            </View>
          </View>
        </Media>
      </MediaContextProvider>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#EEE7E7",
    display: "flex",
    alignContent: "center",
    justifyContent: "center",
    width: "100%",
    maxWidth: 1200,
    // minWidth: 500,
    marginLeft: "auto",
    marginRight: "auto",
    // borderWidth: 5,
    // borderColor: "red",
  },
  box: {
    display: "flex",
    alignItems: "flex-end",
    justifyContent: "flex-end",

    width: 1300,
  },
});
