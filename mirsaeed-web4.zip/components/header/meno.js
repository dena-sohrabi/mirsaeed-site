import { StyleSheet, View, Text } from "react-native";

import { useMediaQuery } from "react-responsive";
import { MenoItem } from "./menoitem";

export function Meno(props) {
  const isMobile = useMediaQuery({ query: "(max-width: 600px)" });

  return (
    <View style={styles.container}>
      <MenoItem title="شبکه های اجتماعی" />
      <MenoItem title="مدارک و سوابق" />
      <MenoItem title="ارتباط با من" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-around",
    flexDirection: "row",
    width: "100%",
    maxWidth: "70%",
  },
});
