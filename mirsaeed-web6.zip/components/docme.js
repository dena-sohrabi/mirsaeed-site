import { StyleSheet, View, Pressable } from "react-native";
import { Media } from "../pages/media";
import { useHover } from "../pages/useHover";
export const Button = ({ title }) => {
  let [hovered, hoverListeners] = useHover();
  return (
    <>
      <Media at="sm">
        <Pressable
          herf="#"
          accessibilityRole="link"
          style={[
            styles.docme,
            { width: 80, height: 30, marginBottom: 20, marginTop: 20 },
            hovered && { backgroundColor: "#b91372", color: "#fff" },
          ]}
          {...hoverListeners}
        >
          {title}
        </Pressable>
      </Media>
      <Media greaterThan="sm">
        <Pressable
          herf="#"
          accessibilityRole="link"
          style={[
            styles.docme,
            hovered && { backgroundColor: "#b91372", color: "#fff" },
          ]}
          {...hoverListeners}
        >
          {title}
        </Pressable>
      </Media>
    </>
  );
};
export const Button2 = ({ title }) => {
  let [hovered, hoverListeners] = useHover();
  return (
    <>
      <Pressable
        accessibilityRole="link"
        herf="#"
        style={[
          styles.docme,
          { marginRight: 50, width: 200 },
          hovered && { backgroundColor: "#b91372", color: "#fff" },
        ]}
        {...hoverListeners}
      >
        رزرو کلاس
      </Pressable>
    </>
  );
};
const styles = StyleSheet.create({
  docme: {
    width: 100,
    height: 40,
    backgroundColor: "#fff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 15,
    shadowColor: "#000",
    marginTop: 35,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.35,
    shadowRadius: 3.84,
    elevation: 5,
  },
});
