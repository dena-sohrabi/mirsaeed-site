import { StyleSheet, Image } from "react-native";
import { Media } from "../../pages/media";
export default function Logo({ source }) {
  return (
    <>
      <Media at="sm">
        <Image
          source={{ uri: source, width: 35, height: 30 }}
          style={styles.logo}
        />
      </Media>
      <Media greaterThan="sm">
        <Image
          source={{ uri: source, width: 45, height: 40 }}
          style={styles.logo}
        />
      </Media>
    </>
  );
}

const styles = StyleSheet.create({});
